import './scss/main.scss';
import App from './lib/app.js'

const app = new App()
app.init()