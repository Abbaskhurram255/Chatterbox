# todo-app-project
Completed todo app project from Andrew Mead's JavaScript course.
