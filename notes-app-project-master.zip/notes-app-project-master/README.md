# notes-app-project
Notes app project from Andrew Mead's JavaScript course
